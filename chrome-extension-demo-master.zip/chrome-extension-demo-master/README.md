# chrome-extension-demo

A demo app to show Amplitude integration in a Chrome Extension. Based off of [Google's Chrome Extension tutorial](https://developer.chrome.com/extensions/getstarted)

Note that the content security policy in `manifest.json` was modified to allow for the loading of Amplitude's JS SDK. Alternatively you may download [Amplitude's JS SDK](https://github.com/amplitude/Amplitude-Javascript) and include it directly.
